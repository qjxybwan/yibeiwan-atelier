/* ==========================================================================
   YBW STUDIO — interactions
   No dependencies. Safe on file:// (no modules, no fetch).
   ========================================================================== */
(function () {
  "use strict";

  /* --- opening sequence -------------------------------------------------- */
  (function intro() {
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var q = new URLSearchParams(window.location.search);
    var force = q.get("intro") === "1";
    var skipParam = q.get("intro") === "0";
    var seen = false;

    try { seen = sessionStorage.getItem("ybw-intro") === "1"; } catch (e) {}
    if (reduce || skipParam || (seen && !force)) return;
    try { sessionStorage.setItem("ybw-intro", "1"); } catch (e) {}

    var current = location.pathname.split("/").pop() || "index.html";

    var mark =
      '<svg viewBox="0 0 48 48" fill="none" aria-hidden="true">' +
      '<path d="M24 2.2 45.4 13.8v20.4L24 45.8 2.6 34.2V13.8L24 2.2Z"/>' +
      '<path d="M14.8 16.8 24 27.6l9.2-10.8"/>' +
      '<path d="M24 27.6v7.4"/>' +
      "</svg>";

    var mods = [
      {
        idx: "01",
        name: "画师背书与维权",
        en: "ENDORSEMENT & RIGHTS",
        desc:
          "为线上线下画师与 Live2D 动效师提供身份背书、合同授权与侵权维权支持。" +
          "盗图、洗稿、拖稿欠款，都有对应的取证与交涉路径；签约画师免费。",
        meta: [
          ["服务对象", "签约画师 / 甲方"],
          ["核心动作", "署名 · 合同 · 取证"],
          ["入口", "服务与报价 / 01"]
        ],
        href: "services.html"
      },
      {
        idx: "02",
        name: "分级合作体系",
        en: "TIERED COLLABORATION",
        desc:
          "A / B 双轨合作：按作品与承接能力分级，决定派单优先级、场地设备支持与分成比例。" +
          "零散商单按需推送，画师自愿承接，不做订单保底。",
        meta: [
          ["体系层级", "A 级 / B 级"],
          ["结算方式", "按单比例分成"],
          ["订单保底", "不承诺"]
        ],
        href: "about.html"
      },
      {
        idx: "03",
        name: "美术定制服务",
        en: "ART COMMISSION",
        desc:
          "插画人设、宣传海报、室内墙绘、Live2D 美术素材，由签约画师落地交付。" +
          "报价按用途、精度、复杂度、修改轮次与周期评估。",
        meta: [
          ["服务品类", "04 类"],
          ["交付物", "源文件 + 授权说明"],
          ["入口", "作品与能力"]
        ],
        href: "works.html"
      },
      {
        idx: "04",
        name: "直接进入首页",
        en: "ENTER SITE",
        desc:
          "跳过说明，直接进入主站。开场动画在本次会话内不会再次播放，也可以随时用导航回到任意板块。",
        meta: [
          ["目标", "首页"],
          ["提示", "数秒后自动进入"],
          ["快捷", "按 Esc 立即进入"]
        ],
        href: "index.html"
      }
    ];

    var rowsHtml = mods
      .map(function (m, i) {
        return (
          '<button class="menu-row" type="button" data-i="' + i + '">' +
            '<span class="row-idx">' + m.idx + "</span>" +
            '<span class="row-nm">' + m.name +
              '<span class="row-en">' + m.en + "</span>" +
            "</span>" +
            '<span class="row-arw">+</span>' +
          "</button>"
        );
      })
      .join("");

    var el = document.createElement("div");
    el.className = "intro";
    el.setAttribute("aria-hidden", "true");
    el.innerHTML =
      '<div class="intro-panels"><i></i><i></i><i></i></div>' +
      '<div class="intro-inner">' +
        '<div class="intro-scan"></div>' +
        '<div class="intro-frame"><i></i><i></i><i></i><i></i></div>' +
        '<div class="intro-data"></div>' +
        '<div class="intro-top"><span>YBW STUDIO</span><span>IBW-000 / BOOT</span></div>' +
        '<div class="intro-center">' +
          '<span class="intro-mark">' + mark + "</span>" +
          '<div class="intro-title" data-text="伊蓓婉工作室">伊蓓婉工作室</div>' +
          '<div class="intro-sub">RIGHTS · CREATIVE · COLLABORATION</div>' +
          '<ul class="intro-log">' +
            "<li>SYSTEM INITIALIZING</li>" +
            "<li>LOADING RIGHTS PROTOCOL</li>" +
            "<li>DECRYPTING MANIFEST</li>" +
            "<li>ALL MODULES READY</li>" +
          "</ul>" +
        "</div>" +
        '<div class="intro-foot">' +
          '<span class="intro-skip">ESC / 点击 跳过</span>' +
          '<div class="intro-meter">' +
            '<span class="intro-track"><span class="intro-bar"></span></span>' +
            '<span class="intro-pct">000</span>' +
          "</div>" +
        "</div>" +
        '<div class="intro-menu">' +
          '<div class="menu-side">' +
            '<p class="menu-kicker">MODULE ACCESS</p>' +
            '<h2 class="menu-title">选择一个入口</h2>' +
            '<p class="menu-hint">点击查看说明 · 数秒后自动进入首页</p>' +
            '<button class="menu-skip" type="button">跳过，直接进入 <span>→</span></button>' +
            '<div class="menu-rows">' + rowsHtml + "</div>" +
          "</div>" +
          '<div class="menu-preview">' +
            '<p class="pv-kicker">MODULE 01</p>' +
            '<h3 class="pv-title"></h3>' +
            '<p class="pv-en"></p>' +
            '<p class="pv-desc"></p>' +
            '<div class="pv-meta"></div>' +
            '<a class="btn btn--primary btn--sm pv-cta" href="services.html">进入该模块 <span class="arw">→</span></a>' +
          "</div>" +
        "</div>" +
        '<div class="intro-grant">' +
          "<b>ACCESS GRANTED</b>" +
          "<span>IDENTITY CONFIRMED · WELCOME</span>" +
        "</div>" +
      "</div>" +
      '<div class="intro-flash"></div>' +
      '<div class="intro-gate">' +
        '<div class="gate-mark"><i></i><i></i><i></i>' + mark + "</div>" +
        '<p class="gate-kicker">YBW STUDIO / SYSTEM STANDBY</p>' +
        '<strong class="gate-enter">点击进入</strong>' +
        '<p class="gate-sub">CLICK ANYWHERE · 或按 ENTER 启动</p>' +
      "</div>";

    document.documentElement.classList.add("intro-lock");
    document.body.appendChild(el);

    var state = "gate";
    var dead = false;
    var timers = [];
    var autoTimer = null;
    var audioCtx = null;

    function later(fn, ms) {
      var t = setTimeout(function () {
        if (!dead) fn();
      }, ms);
      timers.push(t);
      return t;
    }

    /* scrolling data columns */
    var dataBox = el.querySelector(".intro-data");
    if (dataBox) {
      var hex = function () {
        return Math.random().toString(16).slice(2, 6).toUpperCase();
      };
      var block = function () {
        var rows = [];
        for (var i = 0; i < 26; i++) {
          rows.push(hex() + " " + hex() + " " + ("00" + ((Math.random() * 99) | 0)).slice(-3));
        }
        return rows.join("\n");
      };
      for (var c = 0; c < 5; c++) {
        var col = document.createElement("span");
        var txt = block();
        col.textContent = txt + "\n" + txt;
        dataBox.appendChild(col);
      }
    }

    var pctEl = el.querySelector(".intro-pct");
    var barEl = el.querySelector(".intro-bar");
    var rows = el.querySelectorAll(".menu-row");
    var pvKicker = el.querySelector(".pv-kicker");
    var pvTitle = el.querySelector(".pv-title");
    var pvEn = el.querySelector(".pv-en");
    var pvDesc = el.querySelector(".pv-desc");
    var pvMeta = el.querySelector(".pv-meta");
    var pvCta = el.querySelector(".pv-cta");

    function select(i) {
      var m = mods[i];
      if (!m) return;
      for (var k = 0; k < rows.length; k++) {
        rows[k].classList.toggle("is-active", k === i);
        rows[k].setAttribute("aria-pressed", k === i ? "true" : "false");
      }
      pvKicker.textContent = "MODULE " + m.idx;
      pvTitle.textContent = m.name;
      pvEn.textContent = m.en;
      pvDesc.textContent = m.desc;
      pvMeta.innerHTML = m.meta
        .map(function (r) {
          return "<div><dt>" + r[0] + "</dt><dd>" + r[1] + "</dd></div>";
        })
        .join("");
      pvCta.setAttribute("href", m.href);
      pvCta.setAttribute("data-href", m.href);
    }

    function go(href) {
      finish();
      if (href !== current) {
        setTimeout(function () {
          window.location.href = href;
        }, 640);
      }
    }

    /* audio -------------------------------------------------------------- */
    function ensureAudio() {
      try {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return null;
        if (!audioCtx) audioCtx = new Ctx();
        if (audioCtx.state === "suspended" && audioCtx.resume) {
          audioCtx.resume().catch(function () {});
        }
        return audioCtx;
      } catch (e) {
        return null;
      }
    }

    function alarm() {
      var ctx = ensureAudio();
      if (!ctx) return;
      try {
        var t0 = ctx.currentTime + 0.02;
        var master = ctx.createGain();
        master.gain.setValueAtTime(0.0001, t0);
        master.gain.exponentialRampToValueAtTime(0.16, t0 + 0.03);
        master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.95);
        master.connect(ctx.destination);
        [920, 690, 920].forEach(function (freq, i) {
          var osc = ctx.createOscillator();
          var gain = ctx.createGain();
          osc.type = "square";
          osc.frequency.setValueAtTime(freq, t0);
          var st = t0 + i * 0.21;
          gain.gain.setValueAtTime(0.0001, st);
          gain.gain.exponentialRampToValueAtTime(0.5, st + 0.012);
          gain.gain.exponentialRampToValueAtTime(0.0001, st + 0.19);
          osc.connect(gain);
          gain.connect(master);
          osc.start(st);
          osc.stop(st + 0.2);
        });
      } catch (e) {}
    }

    function blip(freq) {
      var ctx = ensureAudio();
      if (!ctx) return;
      try {
        var t0 = ctx.currentTime + 0.005;
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq || 1200, t0);
        gain.gain.setValueAtTime(0.0001, t0);
        gain.gain.exponentialRampToValueAtTime(0.05, t0 + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.09);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t0);
        osc.stop(t0 + 0.1);
      } catch (e) {}
    }

    /* flow --------------------------------------------------------------- */
    var lines = [
      "SYSTEM INITIALIZING",
      "LOADING RIGHTS PROTOCOL",
      "DECRYPTING MANIFEST",
      "ALL MODULES READY"
    ];
    var liEls = el.querySelectorAll(".intro-log li");
    var lineIdx = 0;
    var charIdx = 0;

    function typeStep() {
      if (dead || state !== "boot" || lineIdx >= liEls.length) return;
      var li = liEls[lineIdx];
      if (charIdx === 0) {
        li.classList.add("on", "is-typing");
        li.textContent = "";
      }
      charIdx += 1;
      li.textContent = lines[lineIdx].slice(0, charIdx);
      if (charIdx < lines[lineIdx].length) {
        later(typeStep, 10 + Math.random() * 16);
      } else {
        li.classList.remove("is-typing");
        lineIdx += 1;
        charIdx = 0;
        later(typeStep, 130);
      }
    }

    function glitch() {
      if (dead) return;
      el.classList.add("is-glitch");
      later(function () {
        el.classList.remove("is-glitch");
      }, 250);
    }

    function showMenu() {
      if (dead) return;
      state = "menu";
      el.classList.remove("is-granted");
      el.classList.add("is-menu");
      autoTimer = later(finish, 3200);
    }

    function start() {
      if (state !== "gate") return;
      state = "boot";
      el.classList.add("is-boot");
      ensureAudio();
      blip(880);

      later(typeStep, 300);
      later(glitch, 1000);
      later(glitch, 1800);
      later(glitch, 2400);

      later(function () {
        var t0 = performance.now();
        var dur = 2800;
        (function tick() {
          if (dead || state !== "boot") return;
          var p = Math.min(1, (performance.now() - t0) / dur);
          pctEl.textContent = String(Math.round(p * 100)).padStart(3, "0");
          barEl.style.transform = "scaleX(" + p + ")";
          if (p < 1) {
            setTimeout(tick, 40);
          } else {
            state = "grant";
            el.classList.add("is-granted");
            glitch();
            alarm();
            later(showMenu, 950);
          }
        })();
      }, 280);
    }

    function finish() {
      if (dead) return;
      dead = true;
      state = "out";
      if (autoTimer) clearTimeout(autoTimer);
      for (var i = 0; i < timers.length; i++) clearTimeout(timers[i]);
      el.classList.add("is-out");
      document.documentElement.classList.remove("intro-lock");
      document.removeEventListener("keydown", onKey);
      el.removeEventListener("click", onClick);
      if (audioCtx) {
        setTimeout(function () {
          try { audioCtx.close(); } catch (e) {}
        }, 1200);
      }
      setTimeout(function () {
        if (el.parentNode) el.parentNode.removeChild(el);
      }, 1150);
    }

    function onKey(e) {
      if (e.key === "Escape") {
        finish();
        return;
      }
      if (state === "gate" && (e.key === "Enter" || e.key === " ")) {
        e.preventDefault();
        start();
        return;
      }
      if (state === "boot" || state === "grant" || state === "menu") finish();
    }

    function onClick(e) {
      var row = e.target.closest ? e.target.closest(".menu-row") : null;
      if (row && state === "menu") {
        if (autoTimer) clearTimeout(autoTimer);
        autoTimer = later(finish, 12000);
        select(parseInt(row.getAttribute("data-i"), 10));
        blip(1320);
        return;
      }
      if (e.target.closest && e.target.closest(".menu-preview")) return;
      var skip = e.target.closest ? e.target.closest(".menu-skip") : null;
      if (skip) {
        finish();
        return;
      }
      if (state === "gate") {
        start();
      } else {
        finish();
      }
    }

    for (var r = 0; r < rows.length; r++) {
      rows[r].addEventListener("mouseenter", function (e) {
        if (state !== "menu") return;
        var i = parseInt(e.currentTarget.getAttribute("data-i"), 10);
        if (!rows[i].classList.contains("is-active")) {
          if (autoTimer) clearTimeout(autoTimer);
          autoTimer = later(finish, 12000);
          select(i);
          blip(1600);
        }
      });
    }

    pvCta.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      go(pvCta.getAttribute("data-href") || "index.html");
    });

    el.addEventListener("click", onClick);
    document.addEventListener("keydown", onKey);
    select(0);
  })();

  /* --- mobile navigation ------------------------------------------------- */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.querySelector(".nav");

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = document.body.classList.toggle("nav-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });

    nav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && document.body.classList.contains("nav-open")) {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* --- local clock (HUD) ------------------------------------------------- */
  var clock = document.querySelector("[data-clock]");
  if (clock) {
    var tick = function () {
      var d = new Date();
      var p = function (n) { return String(n).padStart(2, "0"); };
      clock.textContent = p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
    };
    tick();
    setInterval(tick, 1000);
  }

  /* --- reveal on scroll -------------------------------------------------- */
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var items = document.querySelectorAll(".reveal");

  if (reduced || !("IntersectionObserver" in window)) {
    items.forEach(function (el) { el.classList.add("in"); });
  } else {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            io.unobserve(entry.target);
          }
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }
    );
    items.forEach(function (el) { io.observe(el); });

    /* safety net: if the observer never fires, show what is already on screen */
    setTimeout(function () {
      items.forEach(function (el) {
        var r = el.getBoundingClientRect();
        if (r.top < window.innerHeight && r.bottom > 0) el.classList.add("in");
      });
    }, 900);
  }

  /* --- work filters ------------------------------------------------------ */
  var filterBar = document.querySelector("[data-filters]");
  if (filterBar) {
    var cards = Array.prototype.slice.call(document.querySelectorAll("[data-cat]"));
    var countEl = document.querySelector("[data-count]");

    var apply = function (cat) {
      var shown = 0;
      cards.forEach(function (card) {
        var match = cat === "all" || card.getAttribute("data-cat") === cat;
        card.classList.toggle("is-hidden", !match);
        if (match) shown++;
      });
      if (countEl) countEl.textContent = String(shown).padStart(2, "0");
    };

    filterBar.addEventListener("click", function (e) {
      var btn = e.target.closest(".filter");
      if (!btn) return;
      filterBar.querySelectorAll(".filter").forEach(function (b) {
        b.classList.toggle("is-active", b === btn);
        b.setAttribute("aria-pressed", b === btn ? "true" : "false");
      });
      apply(btn.getAttribute("data-cat"));
    });
  }

  /* --- contact form ------------------------------------------------------ */
  var form = document.querySelector("[data-contact-form]");
  if (form) {
    var result = document.querySelector("[data-form-result]");
    var summaryEl = document.querySelector("[data-form-summary]");
    var mailLink = document.querySelector("[data-mail-link]");
    var copyBtn = document.querySelector("[data-copy]");
    var copyLabel = copyBtn ? copyBtn.querySelector("span") : null;

    var buildSummary = function (data) {
      return [
        "称呼：" + data.name,
        "联系方式：" + data.contact,
        "需求类型：" + data.type,
        "预算区间：" + (data.budget || "待沟通"),
        "",
        "需求描述：",
        data.brief
      ].join("\n");
    };

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      var data = {
        name: form.elements.name.value.trim(),
        contact: form.elements.contact.value.trim(),
        type: form.elements.type.value,
        budget: form.elements.budget.value,
        brief: form.elements.brief.value.trim()
      };

      var text = buildSummary(data);
      var subject = "【项目咨询】" + data.type + " — " + data.name;

      if (summaryEl) summaryEl.textContent = text;
      if (mailLink) {
        mailLink.href =
          "mailto:contact@yibeiwan.studio?subject=" +
          encodeURIComponent(subject) +
          "&body=" +
          encodeURIComponent(text);
      }
      if (result) {
        result.classList.add("is-on");
        result.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "center" });
      }

      if (copyBtn) {
        copyBtn.onclick = function () {
          var done = function () {
            copyLabel.textContent = "已复制";
            setTimeout(function () { copyLabel.textContent = "复制需求摘要"; }, 1800);
          };
          if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(done).catch(function () {});
          } else {
            var ta = document.createElement("textarea");
            ta.value = text;
            ta.style.position = "fixed";
            ta.style.opacity = "0";
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand("copy"); done(); } catch (err) {}
            document.body.removeChild(ta);
          }
        };
      }
    });
  }

  /* --- artist onboarding form -------------------------------------------- */
  var joinForm = document.querySelector("[data-join-form]");
  if (joinForm) {
    var joinResult = document.querySelector("[data-form-result]");
    var joinSummary = document.querySelector("[data-form-summary]");
    var joinMail = document.querySelector("[data-mail-link]");
    var joinCopy = document.querySelector("[data-copy]");
    var joinCopyLabel = joinCopy ? joinCopy.querySelector("span") : null;

    joinForm.addEventListener("submit", function (e) {
      e.preventDefault();

      if (!joinForm.checkValidity()) {
        joinForm.reportValidity();
        return;
      }

      var d = {
        name: joinForm.elements.name.value.trim(),
        contact: joinForm.elements.contact.value.trim(),
        portfolio: joinForm.elements.portfolio.value.trim(),
        style: joinForm.elements.style.value.trim() || "未填写",
        types: joinForm.elements.types.value,
        load: joinForm.elements.load.value,
        tier: joinForm.elements.tier.value,
        intro: joinForm.elements.intro.value.trim() || "未填写"
      };

      var text = [
        "称呼：" + d.name,
        "联系方式：" + d.contact,
        "作品集：" + d.portfolio,
        "擅长风格：" + d.style,
        "可承接：" + d.types,
        "每月可接：" + d.load,
        "期望分级：" + d.tier,
        "",
        "自我介绍：",
        d.intro
      ].join("\n");

      var subject = "【画师入驻】" + d.name + " / " + d.types;

      if (joinSummary) joinSummary.textContent = text;
      if (joinMail) {
        joinMail.href =
          "mailto:contact@yibeiwan.studio?subject=" +
          encodeURIComponent(subject) +
          "&body=" +
          encodeURIComponent(text);
      }
      if (joinResult) {
        joinResult.classList.add("is-on");
        joinResult.scrollIntoView({
          behavior: reduced ? "auto" : "smooth",
          block: "center"
        });
      }

      if (joinCopy) {
        joinCopy.onclick = function () {
          var done = function () {
            if (!joinCopyLabel) return;
            joinCopyLabel.textContent = "已复制";
            setTimeout(function () {
              joinCopyLabel.textContent = "复制申请摘要";
            }, 1800);
          };
          if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(done).catch(function () {});
          } else {
            var ta = document.createElement("textarea");
            ta.value = text;
            ta.style.position = "fixed";
            ta.style.opacity = "0";
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand("copy"); done(); } catch (err) {}
            document.body.removeChild(ta);
          }
        };
      }
    });
  }

  /* --- footer year ------------------------------------------------------- */
  document.querySelectorAll("[data-year]").forEach(function (el) {
    el.textContent = String(new Date().getFullYear());
  });
})();
